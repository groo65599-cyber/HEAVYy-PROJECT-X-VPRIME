# HEAVYy PROJECT X Launcher

Android launcher/prototype with:
- Login screen
- DRAG HS / ANTI LAG / GF MC UI toggles
- Crosshair overlay in the HTML UI
- File picker for user-supplied files
- ROG-style performance panel
- Buttons to attempt launching Free Fire / Free Fire MAX

## GitHub build

The included GitHub Actions workflow builds a debug APK automatically.

1. Create a GitHub repository.
2. Upload the contents of this project to the repository.
3. Make sure `.github/workflows/build.yml` is present.
4. Push to the `main` branch, or open **Actions → Build HEAVYy PROJECT X APK → Run workflow**.
5. Open the completed workflow run.
6. At **Artifacts**, download `HEAVYy-PROJECT-X-APK`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

Note: This is a launcher/prototype. It does not inject, modify, or replace Free Fire game data.
